export const Images = {
  background: require('./background.png'),
  girl: require('./girl.png'),
  table: require('./table.png'),
  user: require('./user.png'),
  eight: require('./eight.png'),
  A: require('./A.png'),
  back: require('./back.png'),
};
