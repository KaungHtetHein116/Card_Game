export const CARD_IMAGE_RATIO = 255 / 380;
export const USER_COUNT = 5;
