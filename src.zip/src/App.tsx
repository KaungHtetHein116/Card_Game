import React from 'react';
import CardGesture from './CardGesture';
import CardTable from './CardTable';

const App = () => {
  return <CardTable />;
};

export default App;
